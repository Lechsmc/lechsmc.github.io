export default [
    {
        "name": "请选择代理地址",
        "url": ""
    },
    {
        "name":"isoyu.com",
        "url": "//api.isoyu.com/ckplayer/?url="
    },
    {
        "name": "v.d9y.net",
        "url": "//v.d9y.net/vip/?url="
    },
    {
        "name": "mimijiexi",
        "url": "//mimijiexi.top/?url="
    },
    {
        "name": "55jx",
        "url": "//55jx.top/?url="
    },
    {
        "name": "playx",
        "url": "//playx.top/?url="
    },
    {
        "name": "nitian9",
        "url": "//nitian9.com/?url="
    },
    {
        "name": "19g",
        "url": "//19g.top/?url="
    },
    {
        "name": "52088",
        "url": "//52088.online/?url="
    },
    {
        "name": "5月-21",
        "url": "//jiexi.071811.cc/jx2.php?url="
    },
    {
        "name": "9月-2",
        "url": "//jqaaa.com/jx.php?url="
    },
    {
        "name": "4.21-4",
        "url": "//www.82190555.com/index.php?url="
    },
    {
        "name": "4.21-6",
        "url": "//www.85105052.com/admin.php?url="
    },
    {
        "name": "5月-24",
        "url": "//www.82190555.com/index/qqvod.php?url="
    },
    {
        "name": "1",
        "url": "//17kyun.com/api.php?url="
    },
    {
        "name": "品优解析-可播但广告",
        "url": "//api.pucms.com/xnflv/?url="
    },
    {
        "name": "5月-1",
        "url": "//www.82190555.com/index/qqvod.php?url="
    },
    {
        "name": "腾讯可用，金桥解析",
        "url": "//jqaaa.com/jx.php?url="
    },
    {
        "name": "速度牛",
        "url": "//api.wlzhan.com/sudu/?url="
    },
    {
        "name": "万能接口6",
        "url": "//wwwhe1.177kdy.cn/4.php?pass=1&url="
    },
    {
        "name": "花园影视（可能无效）",
        "url": "//j.zz22x.com/jx/?url="
    },
    {
        "name": "9月-1",
        "url": "//api.ledboke.com/?url="
    }
];