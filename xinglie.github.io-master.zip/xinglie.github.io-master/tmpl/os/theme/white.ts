import Magix from '../../lib/magix';
Magix.applyStyle('@:./white.css');