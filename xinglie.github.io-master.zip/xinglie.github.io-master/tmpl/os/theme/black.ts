import Magix from '../../lib/magix';
Magix.applyStyle('@:./black.css');